#include <cstdio>

int main() {
    printf("Jurij Cerar E1115077");
    return 0;
}
